"""Generate an honest live/final Markdown report from recorded artifacts."""
import argparse,json
from pathlib import Path
import numpy as np
from .common import write,summary

def generate(root,install_root=False):
    root=Path(root);protocol=json.loads((root/'protocol.json').read_text())
    runs=sorted(root.glob('pilot/*/results.json'))+sorted(root.glob('transfer/*/results.json'))+sorted(root.glob('formal/*/results.json'))+sorted(root.glob('imu/*/results.json'))
    statuses=sorted(root.glob('pilot/*/status.json'))+sorted(root.glob('transfer/*/status.json'))+sorted(root.glob('formal/*/status.json'))+sorted(root.glob('imu/*/status.json'))
    completed=[json.loads(p.read_text()) for p in runs]
    final=(root/'final_results.json').exists()
    lines=['# 扑翼机器人：NEAT 拓扑演化、PID 残差控制与 PPO 对照','',
        '**状态：'+('正式评估已完成。' if final else '实验进行中；以下训练/验证结果不是最终结论。')+'**','',
        '上部 7 g、下部 8 g；yaw 和水平位置不控制。本轮目标是姿态稳定、保高及整机保持离地。不能把有限时长通过称为三维定点悬停。','',
        '## 阅读入口','',
        '- [预先保存的实验协议](protocol.json) · [源文件哈希](source_hashes.json) · [传感器/PID 前置检查](preflight.json)','- 各个体、父代、物种、连接创新编号、启用状态、全部权重及节点偏置保存在每代 `generation_*.json.gz`。',
        '- 下方动画显示各代冠军，冠军之间不一定有父子关系；祖先图和权重图另沿真实父代记录生成。','',
        '## 已确认的前置结果','']
    if (root/'preflight.json').exists():
        rows=json.loads((root/'preflight.json').read_text())['episodes']
        lines+=['| 传感器条件 | 场景 | 成功/总数 | 撑满时长 | 倾角 RMS | 高度 RMS |','|---|---|---:|---:|---:|---:|']
        for key in sorted({(r['sensor'],r['case']['condition']) for r in rows}):
            subset=[r for r in rows if (r['sensor'],r['case']['condition'])==key];s=summary(subset)
            lines.append(f'| {key[0]} | {key[1]} | {sum(r["success"] for r in subset)}/{len(subset)} | {sum(r["termination"]=="time_limit" for r in subset)}/{len(subset)} | {s["tilt_rms_deg"]:.2f}° | {s["height_rmse_m"]*100:.2f} cm |')
    lines+=['','高度辅助在这里是 50 Hz、20 ms 延迟、2 mm 测距噪声的模拟测距仪，垂向速度由同一观察器估计。`truth` 是独立真值诊断；`imu` 为纯惯性积分。前置数据不用于最终算法排名。',
        '','加入 ±32 g 量程后，虚拟加速度计的少量高幅脉冲截断可产生明显积分误差；这揭示了现有模型与传感器接口的限制。它不是“实机一定会这样”的结论。姿态读数仍由抽样真值姿态加偏置/噪声模拟 AHRS，并未实现完整姿态解算。',
        '','## 控制和公平性','',
        '- 同一质量、质心、惯性、气动力、电机模型、软启动及执行器伺服。物理步长 5 μs；PID 500 Hz；所有学习策略 100 Hz。',
        '- 残差动作为 `[δα, δβ, δω]`，三个输出均为 `[-1, 1]`，比例为 `[0.035 rad, 0.035 rad, 100 rad/s]`，再叠加固定 PID。实际命令仍受原有物理范围限制。',
        '- 高度辅助策略统一 11 维；纯 IMU 策略统一 9 维。训练/奖励可使用真值，部署策略不读取真实位置、速度、扑翼相位或外力。',
        '- 所有网络先统一 tanh，避免把激活函数更换当成拓扑收益。NEAT 的节点来自非输入节点的连接均使用上一策略时刻状态。',
        '- PPO 为本目录显式实现的 clipped PPO，包含 GAE、终止/时间截断区分、循环序列梯度与导出一致性检查。循环对照和拓扑移植使用同一图更新规则。',
        '- 直接 PPO 另用 PID 演示初始化；演示数据和交互数单列，不把这个额外先验隐藏在相同预算中。',
        '- 训练预算按实际交互数记录，包括 NEAT 全种群评估；验证、演示和拓扑搜索成本分别记录。固定拓扑进化基线具有 8 个隐藏节点，完整 NEAT 从 2 个隐藏节点起步，故两者的初始容量并非完全一致；同规模随机拓扑移植提供额外结构对照。',
        '- CPU 推理时间使用相同 NumPy 导出路径；稀疏图当前以密集矩阵求值。连接少不等于已经证明微控制器更省电。',
        '','## 训练与验证进度','',
        '| 运行 | 状态 | 训练步数 | 验证步数 | 演示步数 | 验证成功率 | 验证倾角 RMS |','|---|---|---:|---:|---:|---:|---:|']
    for p in statuses:
        try:s=json.loads(p.read_text())
        except (ValueError,OSError):continue
        v=s.get('best_validation') or {};folder=p.parent.relative_to(root)
        lines.append(f'| [{folder}]({folder}/status.json) | {s["status"]} | {s["training_steps"]:,} | {s["validation_steps"]:,} | {s.get("demonstration_steps",0):,} | {v.get("success_rate",0):.0%} | {v.get("tilt_rms_deg",0):.2f}° |')
    lines+=['','以上为验证集选择结果。不同训练种子的验证场景不同，同一种子的方法间保持配对。训练 fitness 随每代场景及训练时长变化，不应只看训练曲线单调性。','',
        '## NEAT 演化可视化','',
        '交互浏览器可以选择代数和任意个体、播放冠军序列、筛选连接权重、显示禁用连接、点击父代、查看全部连接权重及节点偏置。浏览器文件包含完整种群数据，可离线打开。','']
    for folder in sorted(root.glob('*/*')):
        vis=folder/'visuals'
        if not (vis/'explorer.html').exists():continue
        rel=vis.relative_to(root);name=folder.name
        lines +=[f'### {name}','',f'[打开交互演化浏览器]({rel}/explorer.html) · [完整父代关系]({rel}/all_parent_links.json) · [图表说明与数据量]({rel}/visualization_manifest.json)','',
            f'![演化过程与物种]({rel}/evolution_summary.png)','',f'![拓扑变化动画：各代冠军]({rel}/topology_evolution.gif)','',
            f'![验证选中网络]({rel}/selected_topology.png)','',f'![真实祖先路径的权重变化]({rel}/lineage_weights.png)','',
            f'![新增删除与种群权重分布]({rel}/mutations_and_weights.png)','']
    if final:
        result=json.loads((root/'final_results.json').read_text());lines+=['## 正式测试','',result['markdown'],'']
    else:lines+=['## 正式测试','', '尚未完成。没有把正在训练的分数写成 NEAT 或 PPO 胜出的结论。','']
    lines+=['## 证据边界','',
        '所有数据来自仿真。模型原有机器人碰撞掩码关闭，离地标准采用全机器人几何包围盒下界，不代表接触力仿真或实机防碰撞验证。初始条件是约 0.8 m 静止释放和 100 ms 电机升速，不是地面自主起飞。初始高度作为准确释放参考；后续高度反馈才来自测距模型。',
        '', '如果连接移除或随机化导致性能下降，只说明该已训练网络对连接敏感；只有重新训练和同规模拓扑对照，才更有力地支持结构价值。','',
        '## 参考依据','',
        '- [NEAT 原始论文与结构消融](https://nn.cs.utexas.edu/downloads/papers/stanley.ec02.pdf)。',
        '- [Flappy Hummingbird：反馈控制上的 DDPG 附加控制](https://arxiv.org/html/1902.09628)。',
        '- [扑翼悬停的行为克隆＋PPO，使用外部状态反馈](https://arxiv.org/html/2502.12355v1)。',
        '- [结构演化与 actor–critic 结合的既有研究](https://arxiv.org/abs/1910.12824)。',
        '', '## Material Passport','',
        '- Origin Skill: academic-research-suite / experiment-agent；当前任务内执行，未委派子代理。',
        '- Mode: experiment execution, audit, scientific visualization。',
        '- Verification: 仿真结果按文件记录；最终结论必须与正式评估状态一致。',
        '- Version: topology_hover_20261008。']
    (root/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    if install_root:
        target=Path('report.md');old=target.read_text() if target.exists() else ''
        marker='<!-- topology-hover-index -->'
        if marker not in old:
            target.write_text(f'{marker}\n# 最新实验：拓扑演化与 PPO 对照\n\n[打开完整 report.md]({root.as_posix()}/report.md)\n\n本轮含每代种群、拓扑动画、真实父代链、权重变化和交互浏览器。\n\n---\n\n'+old,encoding='utf8')
    return root/'report.md'

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--install-root',action='store_true');a=p.parse_args();print(generate(a.root,a.install_root))
